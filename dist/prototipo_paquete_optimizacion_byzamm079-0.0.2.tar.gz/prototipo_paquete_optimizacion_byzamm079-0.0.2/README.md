# paquete_optimizacion
Se muestra una libreria con distintas funciones de optimizacion
